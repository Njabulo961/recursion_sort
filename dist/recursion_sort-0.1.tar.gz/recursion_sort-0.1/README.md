- recursion_sort is a python package with recursive functions and sorting algorithms

There are two modules in this  package:
1. recursion.py
2. sorting.py

- Inside recursion.py:
    1. sum_arry()
    2. fibonacci()
    3. factorial()
    4. reverse()

- Inside sorting.py:
    1. bubble_sort()
    2. merge_sort()
    3. quick_sort()